import 'package:flutter/material.dart';

void main() => runApp(const UP22LiveApp());

class UP22LiveApp extends StatelessWidget {
  const UP22LiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UP22 Live',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F0C20),
        primaryColor: const Color(0xFFFF007F),
      ),
      home: const AuthScreen(),
    );
  }
}

// 1. AUTHENTICATION & LOGIN SCREEN
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final TextEditingController _nameController = TextEditingController();

  void _login(String type) {
    String userName = _nameController.text.trim().isEmpty ? 'User_${DateTime.now().millisecond}' : _nameController.text.trim();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => MainNavigation(userName: userName)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1E0836), Color(0xFF0F0C20)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.rocket_launch, size: 80, color: Color(0xFFFFD700)),
            const SizedBox(height: 10),
            const Text(
              'UP22 LIVE',
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 2, color: Colors.white),
            ),
            const Text('Voice Party & Mega Live Streaming', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 40),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                hintText: 'Enter Nickname / User ID',
                filled: true,
                fillColor: const Color(0xFF231B42),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                prefixIcon: const Icon(Icons.person, color: Colors.pinkAccent),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4285F4),
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              icon: const Icon(Icons.g_mobiledata, size: 30, color: Colors.white),
              label: const Text('Sign in with Google', style: TextStyle(fontSize: 16, color: Colors.white)),
              onPressed: () => _login('google'),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00C853),
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              icon: const Icon(Icons.phone, color: Colors.white),
              label: const Text('Phone Number OTP', style: TextStyle(fontSize: 16, color: Colors.white)),
              onPressed: () => _login('phone'),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () => _login('guest'),
              child: const Text('Quick Guest Login →', style: TextStyle(color: Colors.pinkAccent, fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}

// 2. MAIN BOTTOM NAVIGATION BAR
class MainNavigation extends StatefulWidget {
  final String userName;
  const MainNavigation({super.key, required this.userName});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;
  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      HomeScreen(userName: widget.userName),
      const Center(child: Text('Moments & Feed', style: TextStyle(fontSize: 20))),
      const Center(child: Text('Direct Messages & Chats', style: TextStyle(fontSize: 20))),
      ProfileScreen(userName: widget.userName),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        backgroundColor: const Color(0xFF16122B),
        selectedItemColor: const Color(0xFFFF007F),
        unselectedItemColor: Colors.white54,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_filled), label: 'Live'),
          BottomNavigationBarItem(icon: Icon(Icons.explore), label: 'Moments'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble), label: 'Messages'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

// 3. HOME LOBBY & DISCOVERY SCREEN
class HomeScreen extends StatelessWidget {
  final String userName;
  const HomeScreen({super.key, required this.userName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('UP22 Live', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          IconButton(icon: const Icon(Icons.notifications_none), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Colors.purple, Colors.pinkAccent]),
                borderRadius: BorderRadius.circular(15),
              ),
              padding: const EdgeInsets.all(16),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('🔥 Mega Voice Contest', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Win 50,000 Free Diamonds & Badges', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('Trending Voice Rooms', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.85,
              ),
              itemCount: 4,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => VoicePartyRoom(userName: userName)),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF231B42),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 110,
                          decoration: BoxDecoration(
                            color: Colors.deepPurpleAccent,
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                          ),
                          child: const Center(child: Icon(Icons.mic, size: 50, color: Colors.white)),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Room #${index + 1} Mega Party', style: const TextStyle(fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              const Row(
                                children: [
                                  Icon(Icons.whatshot, color: Colors.orange, size: 16),
                                  Text(' 1.2k', style: TextStyle(color: Colors.white70, fontSize: 12)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFFFF007F),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => VoicePartyRoom(userName: userName)),
        ),
        icon: const Icon(Icons.add_circle_outline),
        label: const Text('Start Party'),
      ),
    );
  }
}

// 4. 17-SEAT COMPLETE PARTY ROOM WITH CONTROLS
class VoicePartyRoom extends StatefulWidget {
  final String userName;
  const VoicePartyRoom({super.key, required this.userName});

  @override
  State<VoicePartyRoom> createState() => _VoicePartyRoomState();
}

class _VoicePartyRoomState extends State<VoicePartyRoom> {
  int coins = 1000;
  bool isMicOn = false;

  void _sendGift(String giftName, int cost) {
    if (coins >= cost) {
      setState(() => coins -= cost);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('🚀 Sent $giftName! Remaining Coins: $coins')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('⚠️ Insufficient Coins! Please Top Up.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🔥 17-Seat Mega Party Room'),
        backgroundColor: Colors.transparent,
        actions: [
          Row(
            children: [
              const Icon(Icons.monetization_on, color: Color(0xFFFFD700), size: 20),
              Text(' $coins ', style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          IconButton(icon: const Icon(Icons.settings), onPressed: () {}),
        ],
      ),
      body: Column(
        children: [
          const CircleAvatar(radius: 35, backgroundColor: Color(0xFFFF007F), child: Icon(Icons.star, size: 35, color: Colors.white)),
          const Text('Host: VIP Admin', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: 16,
              itemBuilder: (context, index) {
                return Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF231B42),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.pinkAccent.withOpacity(0.3)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.person_outline, color: Colors.white54),
                      Text('Seat ${index + 1}', style: const TextStyle(fontSize: 10, color: Colors.white70)),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: Color(0xFF16122B),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(
                  icon: Icon(isMicOn ? Icons.mic : Icons.mic_off, color: isMicOn ? Colors.green : Colors.red),
                  onPressed: () => setState(() => isMicOn = !isMicOn),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF007F)),
                  icon: const Icon(Icons.card_giftcard),
                  label: const Text('Gift Rocket (100)'),
                  onPressed: () => _sendGift('Super Rocket', 100),
                ),
                IconButton(
                  icon: const Icon(Icons.admin_panel_settings, color: Colors.amber),
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// 5. USER PROFILE SCREEN
class ProfileScreen extends StatelessWidget {
  final String userName;
  const ProfileScreen({super.key, required this.userName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile'), backgroundColor: Colors.transparent),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const CircleAvatar(radius: 45, backgroundColor: Color(0xFFFF007F), child: Icon(Icons.person, size: 50, color: Colors.white)),
            const SizedBox(height: 10),
            Text(userName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const Text('UP22 ID: 9845120 | Lv. 10 God-Mode', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 25),
            ListTile(
              tileColor: const Color(0xFF231B42),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              leading: const Icon(Icons.account_balance_wallet, color: Colors.amber),
              title: const Text('Coin Wallet & Top-Up'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}
