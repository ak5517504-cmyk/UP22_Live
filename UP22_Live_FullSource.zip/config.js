const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = 'https://juafxikegdlkomlbracp.supabase.co';
const SUPABASE_ANON_KEY = 'Sb_publishable_CkOGiWKTgonTHIsPMBgKlA_Tv7EAYkW';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

module.exports = supabase;
