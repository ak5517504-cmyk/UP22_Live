package com.up22live.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
