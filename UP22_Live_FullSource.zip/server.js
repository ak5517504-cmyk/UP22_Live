const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const supabase = require('./config');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// 1. हार्डवेयर डिवाइस बैन चेक मिडलवेयर
app.use(async (req, res, next) => {
  const deviceId = req.headers['x-device-id'];
  if (deviceId) {
    const { data: banned } = await supabase
      .from('blacklisted_devices')
      .select('*')
      .eq('device_id', deviceId)
      .single();
    if (banned) {
      return res.status(403).json({ error: 'Device Blocked by Admin' });
    }
  }
  next();
});

// 2. लेवल और EXP ऑटो-अपडेटर
async function addExpAndCoins(userId, expGain, coinGain) {
  const { data: user } = await supabase.from('profiles').select('*').eq('id', userId).single();
  if (!user) return;

  let newExp = (user.exp || 0) + expGain;
  let newCoins = (user.coins || 0) + coinGain;
  let newLevel = Math.min(100, Math.floor(newExp / 100) + 1);

  await supabase.from('profiles').update({
    exp: newExp,
    coins: newCoins,
    level: newLevel
  }).eq('id', userId);
}

// 3. ओनर गॉड-मोड: अनलिमिटेड कॉइन इंजेक्शन
app.post('/api/owner/inject-coins', async (req, res) => {
  const { ownerId, targetUserId, amount } = req.body;
  const { data: owner } = await supabase.from('profiles').select('is_owner').eq('id', ownerId).single();
  
  if (!owner || !owner.is_owner) {
    return res.status(403).json({ error: 'Unauthorized: Only Owner Allowed' });
  }

  await addExpAndCoins(targetUserId, 0, amount);
  res.json({ success: true, message: `Successfully injected ${amount} coins` });
});

// 4. हार्डवेयर डिवाइस सस्पेंड (ओनर पैनल से)
app.post('/api/owner/ban-device', async (req, res) => {
  const { ownerId, deviceId, reason } = req.body;
  const { data: owner } = await supabase.from('profiles').select('is_owner').eq('id', ownerId).single();
  
  if (!owner || !owner.is_owner) return res.status(403).json({ error: 'Unauthorized' });

  await supabase.from('blacklisted_devices').insert([{ device_id: deviceId, reason: reason }]);
  await supabase.from('profiles').update({ is_banned: true }).eq('device_id', deviceId);
  
  res.json({ success: true, message: 'Device permanently blacklisted' });
});

// 5. कॉइन सेलर ट्रांसफर सिस्टम
app.post('/api/seller/transfer', async (req, res) => {
  const { sellerId, targetUserId, amount } = req.body;
  const { data: seller } = await supabase.from('profiles').select('*').eq('id', sellerId).single();

  if (!seller || (!seller.is_coin_seller && !seller.is_owner)) {
    return res.status(403).json({ error: 'Not authorized as seller' });
  }

  if (seller.coins < amount && !seller.is_owner) {
    return res.status(400).json({ error: 'Insufficient coin balance' });
  }

  if (!seller.is_owner) {
    await supabase.from('profiles').update({ coins: seller.coins - amount }).eq('id', sellerId);
  }
  await addExpAndCoins(targetUserId, 0, amount);

  res.json({ success: true, message: `Transferred ${amount} coins` });
});

// 6. लकी रॉकेट और गिफ्टिंग इंजन
app.post('/api/room/send-gift', async (req, res) => {
  const { senderId, roomId, giftName, coins, isRocket } = req.body;
  const { data: sender } = await supabase.from('profiles').select('*').eq('id', senderId).single();

  if (!sender || sender.coins < coins) {
    return res.status(400).json({ error: 'Insufficient coins' });
  }

  // कॉइन काटना और EXP बढ़ाना
  await supabase.from('profiles').update({ 
    coins: sender.coins - coins,
    exp: sender.exp + coins 
  }).eq('id', senderId);

  // गिफ्ट रिकॉर्ड दर्ज करना
  await supabase.from('room_gifts').insert([{
    sender_id: senderId,
    room_id: roomId,
    gift_name: giftName,
    coins: coins,
    is_rocket: isRocket
  }]);

  res.json({ 
    success: true, 
    rocketTriggered: isRocket,
    message: isRocket ? 'Lucky Rocket Launched! Global Drop Active!' : 'Gift Sent!' 
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`UP22 Live Master Server running on port ${PORT}`);
});
